package PageObject.Onliner.Pages;

import PageObject.BaseGroup;
import org.openqa.selenium.WebDriver;

public class MobilePhonesPage extends BaseGroup {

    public MobilePhonesPage(WebDriver driver) {
        super(driver);
    }


}
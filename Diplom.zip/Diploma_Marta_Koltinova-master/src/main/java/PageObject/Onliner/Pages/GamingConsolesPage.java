package PageObject.Onliner.Pages;

import PageObject.BaseGroup;
import org.openqa.selenium.WebDriver;

public class GamingConsolesPage extends BaseGroup {

    public GamingConsolesPage(WebDriver driver) {
        super(driver);
    }


}
